package com.ismailforji.nazzel

import android.app.Activity
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.os.Environment
import android.view.Gravity
import android.view.View
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.text.InputType
import android.widget.*
import androidx.lifecycle.lifecycleScope
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.yausername.youtubedl_android.YoutubeDL
import com.yausername.youtubedl_android.YoutubeDLRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : Activity() {
    private lateinit var urlInput: EditText
    private lateinit var statusText: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var downloadButton: MaterialButton
    private lateinit var infoButton: MaterialButton
    private lateinit var cancelButton: MaterialButton
    private lateinit var qualitySpinner: Spinner
    private var downloadRunning = false
    private var activeProcessId = "nazzel-download"

    private val bg = Color.rgb(10, 24, 28)
    private val card = Color.rgb(20, 42, 45)
    private val accent = Color.rgb(43, 190, 142)
    private val white = Color.rgb(245, 248, 246)
    private val muted = Color.rgb(175, 194, 190)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        buildUi()
        consumeSharedIntent(intent)
    }

    override fun onNewIntent(intent: android.content.Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        consumeSharedIntent(intent)
    }

    private fun consumeSharedIntent(intent: android.content.Intent?) {
        if (intent == null) return
        val shared = when (intent.action) {
            android.content.Intent.ACTION_SEND -> intent.getCharSequenceExtra(android.content.Intent.EXTRA_TEXT)?.toString()
            android.content.Intent.ACTION_VIEW -> intent.dataString
            else -> null
        }?.trim()
        if (!shared.isNullOrBlank() && ::urlInput.isInitialized) {
            val match = Regex("https?://\\S+", RegexOption.IGNORE_CASE).find(shared)?.value ?: shared
            if (validUrl(match)) urlInput.setText(match)
        }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(20), dp(20), dp(24))
            setBackgroundColor(bg)
            layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        val scroll = ScrollView(this).apply { addView(root) }

        val brand = TextView(this).apply {
            text = "تنزيل آمن"
            textSize = 30f
            setTextColor(white)
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(brand, matchWrap())
        root.addView(TextView(this).apply {
            text = "نزّل الفيديو والصوت من رابطك"
            textSize = 15f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(20))
        }, matchWrap())

        val panel = MaterialCardView(this).apply {
            radius = dp(22).toFloat()
            cardElevation = dp(2).toFloat()
            setCardBackgroundColor(card)
            setContentPadding(dp(16), dp(18), dp(16), dp(18))
        }
        val panelContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        panel.addView(panelContent)
        panelContent.addView(TextView(this).apply {
            text = "رابط الفيديو"
            textSize = 16f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(white)
        }, matchWrap())
        urlInput = EditText(this).apply {
            hint = "الصق رابط YouTube أو Instagram أو Facebook أو X"
            setHintTextColor(Color.rgb(130, 155, 150))
            setTextColor(white)
            textSize = 14f
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            maxLines = 3
            minLines = 2
            setPadding(dp(12), dp(12), dp(12), dp(12))
            setBackgroundColor(Color.rgb(30, 57, 59))
            textDirection = View.TEXT_DIRECTION_LTR
            gravity = Gravity.START or Gravity.CENTER_VERTICAL
        }
        val inputParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10); bottomMargin = dp(12) }
        panelContent.addView(urlInput, inputParams)

        val pasteButton = MaterialButton(this).apply {
            text = "لصق الرابط"
            setTextColor(white)
            setBackgroundColor(Color.rgb(48, 73, 74))
            setOnClickListener {
                val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                val clip = clipboard.primaryClip
                if (clip != null && clip.itemCount > 0) urlInput.setText(clip.getItemAt(0).coerceToText(this@MainActivity).toString())
                else showToast("لا يوجد رابط في الحافظة")
            }
        }
        panelContent.addView(pasteButton, matchWrap())

        panelContent.addView(TextView(this).apply {
            text = "الجودة / الصيغة"
            textSize = 14f
            setTextColor(white)
            setPadding(0, dp(14), 0, dp(4))
        }, matchWrap())
        qualitySpinner = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item,
                listOf("أفضل جودة متاحة", "1080p", "720p", "480p", "الصوت فقط — MP3"))
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        panelContent.addView(qualitySpinner, matchWrap())

        infoButton = MaterialButton(this).apply {
            text = "فحص الرابط"
            setTextColor(white)
            setBackgroundColor(Color.rgb(47, 99, 88))
        }
        val infoParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        panelContent.addView(infoButton, infoParams)

        downloadButton = MaterialButton(this).apply {
            text = "تنزيل بأفضل جودة متاحة"
            textSize = 15f
            setTextColor(Color.rgb(7, 28, 23))
            setBackgroundColor(accent)
        }
        val downloadParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) }
        panelContent.addView(downloadButton, downloadParams)
        cancelButton = MaterialButton(this).apply {
            text = "إلغاء التنزيل"
            setTextColor(white)
            setBackgroundColor(Color.rgb(130, 53, 53))
            visibility = View.GONE
            setOnClickListener {
                try { YoutubeDL.getInstance().destroyProcessById(activeProcessId) } catch (_: Exception) {}
                statusText.text = "تم إرسال طلب إيقاف التنزيل."
                setBusy(false)
            }
        }
        panelContent.addView(cancelButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        val historyButton = MaterialButton(this).apply {
            text = "عرض الملفات التي تم تنزيلها"
            setTextColor(white)
            setBackgroundColor(Color.rgb(48, 73, 74))
            setOnClickListener { showHistory() }
        }
        panelContent.addView(historyButton, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        root.addView(panel, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            max = 100
            progress = 0
            progressTintList = android.content.res.ColorStateList.valueOf(accent)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(48, 70, 70))
        }
        root.addView(progressBar, LinearLayout.LayoutParams(-1, dp(8)).apply { topMargin = dp(22) })
        statusText = TextView(this).apply {
            text = "جاهز. الصق رابطًا عامًا ثم افحصه أو ابدأ التنزيل."
            textSize = 14f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(dp(4), dp(14), dp(4), dp(12))
        }
        root.addView(statusText, matchWrap())

        val sites = TextView(this).apply {
            text = "YouTube  •  Instagram  •  Facebook  •  X"
            textSize = 13f
            setTextColor(accent)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(6))
        }
        root.addView(sites, matchWrap())
        root.addView(TextView(this).apply {
            text = "تختلف إمكانية التنزيل حسب إتاحة الفيديو وتغييرات المنصة. لا نرفع روابطك إلى خادم خاص بهذا التطبيق."
            textSize = 12f
            setTextColor(muted)
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }, matchWrap())

        setContentView(scroll)
        infoButton.setOnClickListener { inspectLink() }
        downloadButton.setOnClickListener { startDownload() }
    }

    private fun inspectLink() {
        val url = urlInput.text.toString().trim()
        if (!validUrl(url)) { showToast("أدخل رابط http أو https صحيحًا"); return }
        hideKeyboard()
        setBusy(true, "جارٍ فحص الرابط واستخراج معلومات الفيديو…")
        lifecycleScope.launch {
            try {
                val info = withContext(Dispatchers.IO) { YoutubeDL.getInstance().getInfo(url) }
                statusText.text = "العنوان: ${info.title ?: "فيديو"}\nتم العثور على معلومات الفيديو. يمكنك بدء التنزيل."
            } catch (e: Exception) {
                statusText.text = "تعذر فحص الرابط: ${friendlyError(e)}"
            } finally { setBusy(false) }
        }
    }

    private fun startDownload() {
        val url = urlInput.text.toString().trim()
        if (!validUrl(url)) { showToast("أدخل رابط http أو https صحيحًا"); return }
        hideKeyboard()
        val outDir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "تنزيل آمن")
        if (!outDir.exists() && !outDir.mkdirs()) {
            statusText.text = "تعذر إنشاء مجلد التنزيل. تحقق من مساحة التخزين وأذونات النظام."
            return
        }
        setBusy(true, "جارٍ بدء التنزيل…")
        progressBar.progress = 0
        lifecycleScope.launch {
            try {
                val request = YoutubeDLRequest(url).apply {
                    addOption("--no-playlist")
                    addOption("--no-mtime")
                    addOption("--newline")
                    val selected = qualitySpinner.selectedItemPosition
                    when (selected) {
                        1 -> addOption("-f", "bestvideo[height<=1080]+bestaudio/best[height<=1080]/best")
                        2 -> addOption("-f", "bestvideo[height<=720]+bestaudio/best[height<=720]/best")
                        3 -> addOption("-f", "bestvideo[height<=480]+bestaudio/best[height<=480]/best")
                        4 -> { addOption("-x"); addOption("--audio-format", "mp3"); addOption("--audio-quality", "0") }
                        else -> addOption("-f", "bestvideo*+bestaudio/best")
                    }
                    if (selected != 4) addOption("--merge-output-format", "mp4")
                    addOption("-o", File(outDir, "%(title).180B.%(ext)s").absolutePath)
                }
                withContext(Dispatchers.IO) {
                    YoutubeDL.getInstance().execute(request, { progress, eta ->
                        runOnUiThread {
                            progressBar.progress = progress.toInt().coerceIn(0, 100)
                            statusText.text = "جارٍ التنزيل: ${progress.toInt().coerceIn(0, 100)}%" +
                                if (eta > 0) " • الوقت المتبقي نحو ${eta} ثانية" else ""
                        }
                    }, activeProcessId)
                }
                progressBar.progress = 100
                statusText.text = "اكتمل التنزيل. تحقق من مجلد Download/تنزيل آمن في هاتفك."
            } catch (e: Exception) {
                statusText.text = "فشل التنزيل: ${friendlyError(e)}\nقد يكون الرابط خاصًا أو تتطلب المنصة تحديث محرك التنزيل."
            } finally { setBusy(false) }
        }
    }

    private fun validUrl(value: String): Boolean = try {
        val u = java.net.URI(value)
        (u.scheme == "https" || u.scheme == "http") && !u.host.isNullOrBlank()
    } catch (_: Exception) { false }

    private fun friendlyError(e: Throwable): String = (e.message ?: e.javaClass.simpleName)
        .replace(Regex("\\s+"), " ").take(220)

    private fun setBusy(busy: Boolean, message: String? = null) {
        downloadRunning = busy
        cancelButton.visibility = if (busy) View.VISIBLE else View.GONE
        qualitySpinner.isEnabled = !busy
        downloadButton.isEnabled = !busy
        infoButton.isEnabled = !busy
        if (message != null) statusText.text = message
        if (!busy) {
            downloadButton.text = "تنزيل بأفضل جودة متاحة"
            infoButton.text = "فحص الرابط"
        } else {
            downloadButton.text = "جارٍ العمل…"
            infoButton.text = "يرجى الانتظار…"
        }
    }

    private fun showHistory() {
        val folder = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "تنزيل آمن")
        val files = folder.listFiles()?.filter { it.isFile }?.sortedByDescending { it.lastModified() }.orEmpty()
        if (files.isEmpty()) { showToast("لا توجد ملفات في مجلد التنزيل حتى الآن"); return }
        val labels = files.map { "${it.name}  •  ${android.text.format.Formatter.formatShortFileSize(this, it.length())}" }.toTypedArray()
        android.app.AlertDialog.Builder(this)
            .setTitle("الملفات المنزلة")
            .setItems(labels) { _, which ->
                val file = files[which]
                val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
                val mime = if (file.extension.equals("mp3", true)) "audio/mpeg" else "video/*"
                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW).apply {
                    setDataAndType(uri, mime)
                    addFlags(android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                }
                try { startActivity(intent) } catch (_: Exception) { showToast("لا يوجد مشغل مناسب لهذا الملف") }
            }
            .setNegativeButton("إغلاق", null)
            .show()
    }

    private fun hideKeyboard() {
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(urlInput.windowToken, 0)
        urlInput.clearFocus()
    }
    private fun showToast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
}
