package com.ismailforji.nazzel

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import java.net.URI

class UrlValidationTest {
    private fun validUrl(value: String): Boolean = try {
        val u = URI(value)
        (u.scheme == "https" || u.scheme == "http") && !u.host.isNullOrBlank()
    } catch (_: Exception) { false }

    @Test fun acceptsHttpsUrl() { assertTrue(validUrl("https://www.youtube.com/watch?v=example")) }
    @Test fun rejectsPlainText() { assertFalse(validUrl("not a url")) }
    @Test fun rejectsNonHttpSchemes() { assertFalse(validUrl("file:///etc/passwd")) }
}
