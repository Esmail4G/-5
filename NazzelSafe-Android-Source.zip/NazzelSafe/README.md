# تنزيل آمن — Android source project

**Developer label:** إسماعيل فورجي (Ismail Forji)  
**Application ID:** `com.ismailforji.nazzel`  
**Version:** 1.0.0 (initial independent implementation)

This is a native Kotlin Android project. It does not use Expo, Firebase, a private API server, or a paid build service. The downloader runs on-device through `youtubedl-android` (yt-dlp + embedded Python) and FFmpeg.

## Included in this source package

- Arabic RTL Android UI.
- Link validation and paste-from-clipboard action.
- Link inspection using yt-dlp metadata extraction.
- Video quality choices: best available, up to 1080p/720p/480p, and audio-only MP3.
- Download progress display and a cancel action.
- Save output under `Download/تنزيل آمن`.
- Basic local downloaded-file list and open action.
- GitHub Actions workflow to build a debug APK and publish it as an artifact.
- Basic URL validation unit tests.

## Build the APK

Requirements: JDK 17, Android SDK Platform 35, and Gradle 8.9.

```bash
gradle --no-daemon assembleDebug testDebugUnitTest
```

Expected APK path:

`app/build/outputs/apk/debug/app-debug.apk`

Or upload this ZIP's contents to a GitHub repository and run **Actions → Build Android APK → Run workflow**. The workflow artifact is named `nazzel-safe-debug-apk`.

## Important honest status

The project source is prepared, but this environment did not have Android SDK/Gradle installed and could not reach GitHub to download tools. Therefore, **the APK has not been built or installed/tested in this session**. The GitHub Actions workflow is included as the reproducible build route; the first CI run is the build verification gate.

The included yt-dlp engine supports many sites, but platform extractors can break when websites change. Private/login-gated content may fail unless the user has authorized access and the engine supports the required session. No downloader can honestly promise every link, every time. This app does not ask for platform passwords or upload links to a developer server.

## Permissions and storage notes

- Network access is required for metadata and downloads.
- Output is directed to the public Downloads directory, in `تنزيل آمن`.
- Android storage behavior varies by OS version and device vendor. Validate writes/opening on Android 10–16 during device testing.
- Notifications/foreground-service support is declared for future/background execution, but this initial implementation currently performs the download while the activity process is alive; do not advertise reliable long-running background downloads until a foreground download service is implemented and tested.

## Third-party software / license review

This project integrates `io.github.junkfood02.youtubedl-android` 0.18.1 and its FFmpeg module. Review the upstream license and redistribution requirements before publishing or distributing a release APK: https://github.com/yausername/youtubedl-android . Include all required third-party license notices in a public release. yt-dlp and bundled components have their own licensing obligations.

Use only for content you own or are authorized to download, and comply with source-platform terms and applicable law.
