# Third-party notices

This app integrates `youtubedl-android` and its FFmpeg module, version 0.18.1, from:
https://github.com/yausername/youtubedl-android

Before distributing an APK publicly, inspect the exact licenses of the wrapper, yt-dlp, embedded Python runtime, FFmpeg build, and transitive dependencies, and include the full required license texts and notices. The source wrapper is GPL-3.0; distributing a combined derivative may impose source-distribution obligations. Do not publish the APK until this review is complete.
