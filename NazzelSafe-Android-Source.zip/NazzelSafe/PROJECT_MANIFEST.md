# Project inventory

- Android app module: `app`
- Namespace/application ID: `com.ismailforji.nazzel`
- Main activity: `app/src/main/java/com/ismailforji/nazzel/MainActivity.kt`
- Application bootstrap: `app/src/main/java/com/ismailforji/nazzel/NazzelApp.kt`
- Native downloader: `youtubedl-android` 0.18.1 (yt-dlp + embedded Python)
- Media mux/audio extraction: FFmpeg module 0.18.1
- Build automation: `.github/workflows/build-apk.yml`
- Unit test: URL scheme/host validation

## Not represented as complete yet

- Durable background download service with notification controls.
- Robust download queue and retry/resume across process death.
- Real-device compatibility testing across Android OEMs.
- Platform-by-platform successful test matrix.
- Signed release APK / signing key.

These are explicitly not claimed as complete in this package.
